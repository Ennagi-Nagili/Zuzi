package com.dani.zuzi;

import android.net.Uri;

public class Comment {
    private Uri image;
    private String comment;

    public Uri getImage() {
        return image;
    }

    public void setImage(Uri image) {
        this.image = image;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
