package com.dani.zuzi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class Info extends AppCompatActivity {
    private TextView username, email, number, cat_txt;
    private ImageView profile_image;
    private FirebaseFirestore firestore;
    private DocumentReference reference;
    private DatabaseReference ref, ref2;
    private FirebaseUser user;
    private StorageReference reference2;
    private Button direct;
    private RecyclerView recycler;
    private CategoryAdapter adapter;
    private ArrayList<Category> list;
    private Button add, delete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        username = findViewById(R.id.name_txt);
        email = findViewById(R.id.email_txt);
        number = findViewById(R.id.number_txt);
        cat_txt = findViewById(R.id.cat_txt);
        profile_image = findViewById(R.id.profile_image);
        direct = findViewById(R.id.direct);
        firestore = FirebaseFirestore.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();
        reference = firestore.collection("Users").document(user.getUid());
        reference2 = FirebaseStorage.getInstance().getReference(user.getUid() + ".jpg");
        ref = FirebaseDatabase.getInstance().getReference("Category").child(user.getUid());
        recycler = findViewById(R.id.category_recycler);
        list = new ArrayList<>();
        add = findViewById(R.id.add);
        delete = findViewById(R.id.delete);

        recycler.setHasFixedSize(true);
        LinearLayoutManager manager = new LinearLayoutManager(Info.this, LinearLayoutManager.VERTICAL, false);
        recycler.setLayoutManager(manager);

        direct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Info.this, Direct.class);
                startActivity(intent);
            }
        });

        reference.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            username.setText("İstifadəçi adı: " + documentSnapshot.getData().get("name").toString());
                            email.setText("Email: " + documentSnapshot.getData().get("email").toString());
                            number.setText("Əlaqə nömrəsi:" + documentSnapshot.getData().get("contact").toString());
                        }
                    }
                });

        reference2.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Glide.with(Info.this)
                        .load(uri)
                        .into(profile_image);
            }
        });

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snap: snapshot.getChildren()) {
                    ref2 = ref.child(snap.getKey());

                    ref2.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot1) {
                            for (DataSnapshot snap2: snapshot1.getChildren()) {
                                Category category = new Category();
                                category.setName(snap2.getValue().toString());

                                if (snap2.getValue().toString().equals("Ehtiyat hissələri")) {
                                    category.setImage(R.drawable.image1);
                                }

                                else if (snap2.getValue().toString().equals("Sağlamlıq")) {
                                    category.setImage(R.drawable.image2);
                                }

                                else if (snap2.getValue().toString().equals("Qida")) {
                                    category.setImage(R.drawable.image3);
                                }

                                else if (snap2.getValue().toString().equals("İdman")) {
                                    category.setImage(R.drawable.image4);
                                }

                                else if (snap2.getValue().toString().equals("Texnologiya")) {
                                    category.setImage(R.drawable.image5);
                                }

                                list.add(category);
                            }

                            adapter = new CategoryAdapter(list, Info.this);
                            recycler.setAdapter(adapter);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ref.removeValue();
                finish();
                startActivity(getIntent());
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alert1 = new AlertDialog.Builder(Info.this);

                LayoutInflater inflater = LayoutInflater.from(Info.this);
                final View view1 = inflater.inflate(R.layout.alert, null);
                alert1.setView(view1);
                RecyclerView recycler1 = view1.findViewById(R.id.cat_recycler);
                ProductAdapter adapter1 = new ProductAdapter(Products.getData(), Info.this);

                recycler1.setHasFixedSize(true);
                LinearLayoutManager manager1 = new LinearLayoutManager(Info.this, LinearLayoutManager.VERTICAL, false);
                recycler1.setLayoutManager(manager1);
                recycler1.setAdapter(adapter1);

                adapter1.setOnItemClickListener(new ProductAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(Products products, int position) {
                        Category category = new Category();
                        category.setName(products.getName());
                        category.setImage(products.getImage());

                        boolean check = true;
                        for (int i = 0; i < list.size(); i++) {
                            if (list.get(i).getName().equals(products.getName())) {
                                check = false;
                            }
                        }

                        if (check) {
                            list.add(category);
                            adapter = new CategoryAdapter(list, Info.this);
                            recycler.setAdapter(adapter);

                            HashMap<String, Object> data = new HashMap<>();
                            data.put("category", products.getName());
                            Random random = new Random();
                            ref.child(String.valueOf(random.nextInt())).setValue(data);
                            finish();
                            startActivity(getIntent());
                        }

                        else {
                            Toast.makeText(Info.this, "Bir kateqoriya iki dəfə seçilə bilməz", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                alert1.show();
            }
        });
    }
}