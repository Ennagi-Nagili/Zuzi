package com.dani.zuzi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class Register extends AppCompatActivity {
    private EditText register_email, register_password, register_name, register_repeat, register_contact, register_company, register_voen;
    private TextView new_login;
    private String txt_email, txt_password, txt_name, txt_repeat, txt_contact, txt_company, txt_voen;
    private FirebaseAuth auth;
    private FirebaseUser user;
    private Button signUp, btn_category;
    private HashMap<String, Object> data;
    private FirebaseFirestore firestore;
    private AlertDialog.Builder alert;
    private RecyclerView recycler1;
    private CategoryAdapter adapter1;
    private ArrayList<Category> list;
    private DatabaseReference reference;
    private String category;
    private HashMap<String, Object> data2;
    private ArrayList<String> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        register_email = findViewById(R.id.register_email);
        register_password = findViewById(R.id.register_password);
        register_name = findViewById(R.id.register_name);
        register_repeat = findViewById(R.id.register_repeat);
        register_company = findViewById(R.id.register_company);
        register_voen = findViewById(R.id.register_voen);
        new_login = findViewById(R.id.new_login);
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        signUp = findViewById(R.id.signUp);
        firestore = FirebaseFirestore.getInstance();
        btn_category = findViewById(R.id.btn_category);
        alert = new AlertDialog.Builder(Register.this);
        recycler1 = findViewById(R.id.reg_recycler);
        list = new ArrayList<>();
        register_contact = findViewById(R.id.register_contact);
        data2 = new HashMap<>();
        arrayList = new ArrayList<>();

        recycler1.setHasFixedSize(true);
        LinearLayoutManager manager = new LinearLayoutManager(Register.this, LinearLayoutManager.VERTICAL, false);
        recycler1.setLayoutManager(manager);

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register();
            }
        });

        new_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Register.this, Login.class);
                finish();
                startActivity(intent);
            }
        });

        ArrayList<String> arrayList = new ArrayList();

        btn_category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LayoutInflater inflater = LayoutInflater.from(Register.this);
                final View view1 = inflater.inflate(R.layout.alert, null);
                alert.setView(view1);
                RecyclerView recycler = view1.findViewById(R.id.cat_recycler);
                ProductAdapter adapter = new ProductAdapter(Products.getData(), Register.this);
                SearchView search = view1.findViewById(R.id.search);
                search.clearFocus();

                search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String s) {
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String s) {
                        filterList(s, recycler, adapter);
                        return false;
                    }
                });

                recycler.setHasFixedSize(true);
                LinearLayoutManager manager = new LinearLayoutManager(Register.this, LinearLayoutManager.VERTICAL, false);
                recycler.setLayoutManager(manager);
                recycler.setAdapter(adapter);

                adapter.setOnItemClickListener(new ProductAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(Products products, int position) {
                        Category category = new Category();
                        category.setName(products.getName());
                        category.setImage(products.getImage());

                        boolean check = true;
                        for (int i = 0; i < list.size(); i++) {
                            if (list.get(i).getName().equals(products.getName())) {
                                check = false;
                            }
                        }

                        if (check) {
                            list.add(category);
                            adapter1 = new CategoryAdapter(list, Register.this);
                            recycler1.setAdapter(adapter1);
                            signUp.setEnabled(true);
                        }

                        else {
                            Toast.makeText(Register.this, "Bir kateqoriya iki dəfə seçilə bilməz", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                alert.show();
            }
        });
    }

    public void register() {
        txt_email = register_email.getText().toString();
        txt_password = register_password.getText().toString();
        txt_name = register_name.getText().toString();
        txt_repeat = register_repeat.getText().toString();
        txt_contact = register_contact.getText().toString();
        txt_company = register_company.getText().toString();
        txt_voen = register_voen.getText().toString();

        if (!TextUtils.isEmpty(txt_email) && !TextUtils.isEmpty(txt_password) && !TextUtils.isEmpty(txt_name) && !TextUtils.isEmpty(txt_contact) && !TextUtils.isEmpty(txt_company) && !TextUtils.isEmpty(txt_voen)) {
            if (txt_password.equals(txt_repeat)) {
                auth.createUserWithEmailAndPassword(txt_email, txt_password)
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    user = auth.getCurrentUser();

                                    data = new HashMap<>();
                                    data.put("name", txt_name);
                                    data.put("company", txt_company);
                                    data.put("email", txt_email);
                                    data.put("uid", user.getUid());
                                    data.put("type", "company");
                                    data.put("contact", txt_contact);
                                    data.put("voen", txt_voen);

                                    firestore.collection("Users").document(user.getUid())
                                            .set(data)
                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {
                                                        Toast.makeText(Register.this, "Successfully signed up", Toast.LENGTH_SHORT).show();
                                                        SharedPreferences preferences = getSharedPreferences("com.dani.Zuzi", MODE_PRIVATE);
                                                        SharedPreferences.Editor editor = preferences.edit();
                                                        editor.putString("email", txt_email);
                                                        editor.putString("password", txt_password);
                                                        editor.apply();
                                                        login();
                                                    } else {
                                                        Toast.makeText(Register.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                                    }
                                                }
                                            });

                                    Random random = new Random();

                                    reference = FirebaseDatabase.getInstance().getReference("Category").child(user.getUid());

                                    for (int i = 0; i < list.size(); i++) {
                                        data2.put("category", list.get(i).getName());
                                        reference.child(String.valueOf(random.nextInt())).setValue(data2);
                                    }

                                } else {
                                    Toast.makeText(Register.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }

            else {
                Toast.makeText(Register.this, "Passwords didn't match.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void login() {
        txt_email = register_email.getText().toString();
        txt_password = register_password.getText().toString();
        txt_name = register_name.getText().toString();
        txt_repeat = register_repeat.getText().toString();

        if (!TextUtils.isEmpty(txt_email) && !TextUtils.isEmpty(txt_password)) {
            auth.signInWithEmailAndPassword(txt_email, txt_password)
                    .addOnSuccessListener(this, new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            Intent intent = new Intent(Register.this, Intro.class);
                            finish();
                            startActivity(intent);
                        }
                    }).addOnFailureListener(Register.this, new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(Register.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    public void filterList(String text, RecyclerView recycler, ProductAdapter adapter) {
        ArrayList<Products> list1 = new ArrayList<>();

        for (Products products: Products.getData()) {
            if (products.getName().toLowerCase().contains(text.toLowerCase())) {
                list1.add(products);
            }
        }

        adapter = new ProductAdapter(list1, Register.this);

        adapter.setOnItemClickListener(new ProductAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Products products, int position) {
                Category category = new Category();
                category.setName(products.getName());
                category.setImage(products.getImage());

                boolean check = true;
                for (int i = 0; i < list.size(); i++) {
                    if (list.get(i).getName().equals(products.getName())) {
                        check = false;
                    }
                }

                if (check) {
                    list.add(category);
                    adapter1 = new CategoryAdapter(list, Register.this);
                    recycler1.setAdapter(adapter1);
                    signUp.setEnabled(true);
                }

                else {
                    Toast.makeText(Register.this, "Bir kateqoriya iki dəfə seçilə bilməz", Toast.LENGTH_SHORT).show();
                }
            }
        });

        recycler.setAdapter(adapter);
    }
}