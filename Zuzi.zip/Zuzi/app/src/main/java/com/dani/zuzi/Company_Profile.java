package com.dani.zuzi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class Company_Profile extends AppCompatActivity {
    private TextView name_txt, ceo_txt;
    private Button direct;
    private RecyclerView recycler;
    private CategoryAdapter adapter;
    private ArrayList<Category> list;
    private DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_profile);
        Intent intent = getIntent();
        name_txt = findViewById(R.id.name_txt);
        ceo_txt = findViewById(R.id.ceo_txt);
        direct = findViewById(R.id.direct);
        recycler = findViewById(R.id.category_recycler);
        list = new ArrayList<>();
        reference = FirebaseDatabase.getInstance().getReference("Category").child(intent.getStringExtra("uid"));

        direct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Company_Profile.this, Direct.class);
                startActivity(intent);
            }
        });

        name_txt.setText("Şirkət adı: " +intent.getStringExtra("name"));
        ceo_txt.setText("Ceo: " +intent.getStringExtra("ceo"));

        recycler.setHasFixedSize(true);
        LinearLayoutManager manager = new LinearLayoutManager(Company_Profile.this, LinearLayoutManager.VERTICAL, false);
        recycler.setLayoutManager(manager);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snap: snapshot.getChildren()) {
                    DatabaseReference reference2 = reference.child(snap.getKey());

                    reference2.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot1) {
                            for (DataSnapshot snap1: snapshot1.getChildren()) {
                                Category category = new Category();
                                category.setName(snap1.getValue().toString());

                                if (snap1.getValue().toString().equals("Ehtiyat hissələri")) {
                                    category.setImage(R.drawable.image1);
                                }

                                else if (snap1.getValue().toString().equals("Sağlamlıq")) {
                                    category.setImage(R.drawable.image2);
                                }

                                else if (snap1.getValue().toString().equals("Qida")) {
                                    category.setImage(R.drawable.image3);
                                }

                                else if (snap1.getValue().toString().equals("İdman")) {
                                    category.setImage(R.drawable.image4);
                                }

                                else if (snap1.getValue().toString().equals("Texnologiya")) {
                                    category.setImage(R.drawable.image5);
                                }

                                list.add(category);
                            }

                            adapter = new CategoryAdapter(list, Company_Profile.this);
                            recycler.setAdapter(adapter);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}