package com.dani.zuzi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dani.zuzi.R;

import java.util.ArrayList;

public class SpareCompanyAdapter extends RecyclerView.Adapter<SpareCompanyAdapter.SpareCompanyHolder> {
    private ArrayList<SpareCompany> userList;
    private Context context;
    private OnItemClickListener listener;

    public SpareCompanyAdapter(ArrayList<SpareCompany> userList, Context context) {
        this.userList = userList;
        this.context = context;
    }

    @NonNull
    @Override
    public SpareCompanyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.company, parent, false);
        return new SpareCompanyHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull SpareCompanyHolder holder, int position) {
        SpareCompany spareCompany = userList.get(position);
        holder.setData(spareCompany);
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    class SpareCompanyHolder extends RecyclerView.ViewHolder {
        TextView company, ceo;
        ImageView image;

        public SpareCompanyHolder(@NonNull View itemView) {
            super(itemView);
            company = itemView.findViewById(R.id.company_name);
            ceo = itemView.findViewById(R.id.company_ceo);
            image = itemView.findViewById(R.id.company_image);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();

                    if (listener != null && position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(userList.get(position), position);
                    }
                }
            });
        }

        public void setData(SpareCompany spareCompany) {
            this.company.setText(spareCompany.getCompany());
            this.ceo.setText(spareCompany.getCeo());
            this.image.setImageResource(spareCompany.getImage());
        }
    }

    public interface OnItemClickListener {
        void onItemClick(SpareCompany spareCompany, int position);
    }

    public void setOnItemClickListener(SpareCompanyAdapter.OnItemClickListener listener) {
        this.listener = listener;
    }
}
